import logging
import os

from ..tenable_helper import TenableIO

# ! updated for was_vuln support
severity = os.environ.get("LowestSeveritytoStoreWAS", "info")
SEVERITIES = ["info", "low", "medium", "high", "critical"]


def main(timestamp: int) -> str:
    logging.info("using pyTenable client to create new WAS vuln export job")
    tio = TenableIO()
    logging.info("requesting a new WAS Vuln Export Job from Tenable for timestamp: {}".format(timestamp))
    # limiting number of assets to 50. For some bigger containers,
    # each chunk is reported to be some hundreds of MBs resulting
    # into azure function crash due to OOM errors.
    if severity and severity.lower() in SEVERITIES:
        logging.info("Selected lowest severity: {}".format(severity))
        logging.info(
            "Fetching vulnerability Data for severity: {}".format(
                SEVERITIES[SEVERITIES.index(severity.lower()):]
            )
        )
        job_id = tio.exports.was(
            use_iterator=False,
            num_assets=50,
            indexed_at=timestamp,
            severity=SEVERITIES[SEVERITIES.index(severity.lower()):],
            state=["OPEN", "REOPENED", "FIXED"]
        )
    else:
        logging.warning(
            "Either 'Lowest Severity to Store' parameter is not set or value is not from allowed values"
            "(info,low,medium,high,critical)."
        )
        logging.info(
            "Fetching WAS vulnerability Data for severity {} considering default Info as lowest severity value.".format(
                SEVERITIES
            )
        )
        job_id = tio.exports.was(
            use_iterator=False,
            num_assets=50,
            indexed_at=timestamp,
            severity=SEVERITIES,
            state=["OPEN", "REOPENED", "FIXED"]
        )

    logging.info(f"received a response from WAS Vuln Export Job request{job_id}")
    return str(job_id)
